This is a heatmap.js plugin to visualize data as a heatmap overlay in Google Maps. 


Learn more about how to use heatmap.js and this overlay implementation on the [heatmap website](https://www.patrick-wied.at/static/heatmapjs/?utm_source=npm_gmaps&utm_medium=web)


Google Maps is a trademark of Google Inc. The gmaps-heatmap.js overlay implementation is in no way sponsored or affiliated with Google Inc. 